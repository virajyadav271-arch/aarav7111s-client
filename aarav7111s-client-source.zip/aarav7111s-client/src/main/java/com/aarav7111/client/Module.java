package com.aarav7111.client;

public class Module {
    public final String id;
    public final String name;
    public boolean enabled;

    public Module(String id, String name, boolean enabledByDefault) {
        this.id = id;
        this.name = name;
        this.enabled = enabledByDefault;
    }
}
