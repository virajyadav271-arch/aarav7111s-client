package com.aarav7111.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

public final class Modules {
    public static final Module HUD         = new Module("hud", "Info HUD (FPS/XYZ)", true);
    public static final Module BLOCK_INFO  = new Module("blockinfo", "Targeted Block", true);
    public static final Module CROSSHAIR   = new Module("crosshair", "Custom Crosshair", true);
    public static final Module ZOOM        = new Module("zoom", "Zoom (hold C)", true);
    public static final Module AUTO_SPRINT = new Module("autosprint", "Auto Sprint", true);
    public static final Module FULLBRIGHT  = new Module("fullbright", "Fullbright", false);
    public static final Module FPS_BOOST   = new Module("fpsboost", "FPS Boost", false);
    public static final Module ARMOR_HUD   = new Module("armorhud", "Armor HUD", true);
    public static final Module DURA_WARN   = new Module("durawarn", "Low Durability Warning", true);
    public static final Module POTION_HUD  = new Module("potionhud", "Potion HUD", true);
    public static final Module KEYSTROKES  = new Module("keystrokes", "Keystrokes", true);
    public static final Module CPS         = new Module("cps", "CPS Counter", true);

    public static final List<Module> ALL =
            List.of(HUD, BLOCK_INFO, CROSSHAIR, ZOOM, AUTO_SPRINT, FULLBRIGHT, FPS_BOOST,
            ARMOR_HUD, DURA_WARN, POTION_HUD, KEYSTROKES, CPS);

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("aarav7111sclient.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (InputStream in = Files.newInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            for (Module m : ALL) {
                String v = p.getProperty(m.id);
                if (v != null) m.enabled = Boolean.parseBoolean(v);
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try (OutputStream out = Files.newOutputStream(file())) {
            Properties p = new Properties();
            for (Module m : ALL) p.setProperty(m.id, String.valueOf(m.enabled));
            p.store(out, "Aarav7111s Client modules");
        } catch (Exception ignored) {}
    }

    private Modules() {}
}
