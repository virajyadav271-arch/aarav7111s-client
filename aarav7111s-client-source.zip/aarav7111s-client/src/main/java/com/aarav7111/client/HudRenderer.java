package com.aarav7111.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

public final class HudRenderer {
    private static final EquipmentSlot[] SLOTS =
            {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private static final float WARN_AT = 0.15f; // warn at 15% durability left

    private static final Deque<Long> LMB = new ArrayDeque<>();
    private static final Deque<Long> RMB = new ArrayDeque<>();
    private static boolean prevL, prevR;
    private static final Map<RegistryEntry<StatusEffect>, Integer> MAX_DUR = new HashMap<>();

    private HudRenderer() {}

    // ---------- per-tick CPS tracking ----------
    public static void tick(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        boolean l = mc.options.attackKey.isPressed();
        boolean r = mc.options.useKey.isPressed();
        if (l && !prevL) LMB.add(now);
        if (r && !prevR) RMB.add(now);
        prevL = l;
        prevR = r;
        while (!LMB.isEmpty() && now - LMB.peekFirst() > 1000) LMB.pollFirst();
        while (!RMB.isEmpty() && now - RMB.peekFirst() > 1000) RMB.pollFirst();
    }

    private static int durColor(float pct) {
        if (pct > 0.5f) return 0xFF55FF55;
        if (pct > WARN_AT) return 0xFFFFFF55;
        return 0xFFFF5555;
    }

    // ---------- Armor HUD ----------
    public static void renderArmor(DrawContext ctx, MinecraftClient mc, int x, int y) {
        TextRenderer tr = mc.textRenderer;
        for (EquipmentSlot slot : SLOTS) {
            ItemStack st = mc.player.getEquippedStack(slot);
            if (st.isEmpty()) continue;
            ctx.fill(x - 2, y - 1, x + 84, y + 18, 0x90101018);
            ctx.drawItem(st, x, y);
            if (st.isDamageable()) {
                int max = st.getMaxDamage();
                int left = max - st.getDamage();
                float pct = left / (float) max;
                int c = durColor(pct);
                ctx.drawTextWithShadow(tr, left + "/" + max, x + 20, y + 2, c);
                ctx.fill(x + 20, y + 13, x + 80, y + 15, 0xFF2A2A2A);
                ctx.fill(x + 20, y + 13, x + 20 + (int) (60 * pct), y + 15, c);
            } else {
                ctx.drawTextWithShadow(tr, "-", x + 20, y + 4, 0xFFAAAAAA);
            }
            y += 21;
        }
    }

    // ---------- Low durability warning ----------
    public static void renderWarning(DrawContext ctx, MinecraftClient mc) {
        TextRenderer tr = mc.textRenderer;
        String worstName = null;
        float worst = 1f;
        for (EquipmentSlot slot : SLOTS) {
            ItemStack st = mc.player.getEquippedStack(slot);
            if (st.isEmpty() || !st.isDamageable()) continue;
            float pct = (st.getMaxDamage() - st.getDamage()) / (float) st.getMaxDamage();
            if (pct <= WARN_AT && pct < worst) {
                worst = pct;
                worstName = st.getName().getString();
            }
        }
        if (worstName == null) return;

        float pulse = 0.55f + 0.45f * (float) Math.sin(System.currentTimeMillis() / 180.0);
        int a = Math.max(40, (int) (255 * pulse));
        String text = "! " + worstName + " durability " + Math.max(0, (int) (worst * 100)) + "% !";
        int w = tr.getWidth(text) + 16;
        int x = (ctx.getScaledWindowWidth() - w) / 2;
        int y = ctx.getScaledWindowHeight() / 2 + 34;
        ctx.fill(x, y, x + w, y + 16, ((a / 2) << 24) | 0x440000);
        ctx.fill(x, y, x + w, y + 1, (a << 24) | 0xFF5555);
        ctx.fill(x, y + 15, x + w, y + 16, (a << 24) | 0xFF5555);
        ctx.drawTextWithShadow(tr, text, x + 8, y + 4, (a << 24) | 0xFFFFFF);
    }

    // ---------- Potion HUD ----------
    private static String fmt(int ticks) {
        int s = ticks / 20;
        return String.format("%d:%02d", s / 60, s % 60);
    }

    public static void renderPotions(DrawContext ctx, MinecraftClient mc) {
        TextRenderer tr = mc.textRenderer;
        MAX_DUR.keySet().removeIf(k -> !mc.player.hasStatusEffect(k));

        int pw = 96, ph = 26;
        int x = ctx.getScaledWindowWidth() - pw - 6;
        int y = 6;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            RegistryEntry<StatusEffect> type = e.getEffectType();
            int dur = e.getDuration();
            boolean inf = e.isInfinite();
            MAX_DUR.merge(type, dur, Math::max);
            int max = Math.max(MAX_DUR.get(type), 1);
            boolean good = type.value().isBeneficial();
            int accent = good ? 0xFF55FF55 : 0xFFFF5555;
            boolean lowBlink = !inf && dur < 200 && (System.currentTimeMillis() / 250) % 2 == 0;

            ctx.fill(x, y, x + pw, y + ph, 0xAA101018);
            ctx.fill(x, y, x + 2, y + ph, lowBlink ? 0xFFFFFFFF : accent);

            int amp = Math.min(e.getAmplifier() + 1, ROMAN.length - 1);
            String name = type.value().getName().getString() + (amp > 1 ? " " + ROMAN[amp] : "");
            ctx.drawTextWithShadow(tr, name, x + 7, y + 3, 0xFFFFFFFF);
            String time = inf ? "inf" : fmt(dur);
            ctx.drawTextWithShadow(tr, time, x + pw - tr.getWidth(time) - 4, y + 3,
                    lowBlink ? 0xFFFF5555 : 0xFFAAAAAA);

            int bx = x + 7, bw = pw - 12, by = y + ph - 6;
            ctx.fill(bx, by, bx + bw, by + 2, 0x55FFFFFF);
            float frac = inf ? 1f : Math.min(1f, dur / (float) max);
            ctx.fill(bx, by, bx + (int) (bw * frac), by + 2, accent);
            y += ph + 3;
        }
    }

    // ---------- Keystrokes + CPS ----------
    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                            String label, boolean down) {
        ctx.fill(x, y, x + w, y + h, down ? 0xCCFFFFFF : 0x90101018);
        int c = down ? 0xFF111111 : 0xFFFFFFFF;
        ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, c, false);
    }

    public static void renderKeys(DrawContext ctx, MinecraftClient mc) {
        TextRenderer tr = mc.textRenderer;
        var o = mc.options;
        int s = 18, g = 2;
        int bx = 6, by = ctx.getScaledWindowHeight() - 90;
        key(ctx, tr, bx + s + g, by, s, s, "W", o.forwardKey.isPressed());
        key(ctx, tr, bx, by + s + g, s, s, "A", o.leftKey.isPressed());
        key(ctx, tr, bx + s + g, by + s + g, s, s, "S", o.backKey.isPressed());
        key(ctx, tr, bx + 2 * (s + g), by + s + g, s, s, "D", o.rightKey.isPressed());
        int w = (3 * s + 2 * g - g) / 2;
        int y3 = by + 2 * (s + g);
        String l = Modules.CPS.enabled ? "L " + LMB.size() : "LMB";
        String r = Modules.CPS.enabled ? "R " + RMB.size() : "RMB";
        key(ctx, tr, bx, y3, w, s, l, o.attackKey.isPressed());
        key(ctx, tr, bx + w + g, y3, w, s, r, o.useKey.isPressed());
        key(ctx, tr, bx, y3 + s + g, 3 * s + 2 * g, 10, "SPACE", o.jumpKey.isPressed());
    }

    public static void renderCpsOnly(DrawContext ctx, MinecraftClient mc) {
        ctx.drawTextWithShadow(mc.textRenderer, "CPS: " + LMB.size() + " | " + RMB.size(),
                6, ctx.getScaledWindowHeight() - 30, 0xFFFFFFFF);
    }
}
