package com.aarav7111.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

public class AaravClient implements ClientModInitializer {
    public static final String NAME = "Aarav7111s Client";
    public static final float ZOOM_FACTOR = 4.0f;

    private static KeyBinding menuKey, zoomKey;

    public static boolean isZooming() {
        return Modules.ZOOM.enabled && zoomKey != null && zoomKey.isPressed();
    }

    /** Called when a module is toggled from the menu. */
    public static void onModuleChanged(Module m) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (m == Modules.FPS_BOOST) applyFpsBoost(mc.options, m.enabled);
        if (m == Modules.FULLBRIGHT && !m.enabled && mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    @Override
    public void onInitializeClient() {
        Modules.load();

        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("aarav7111sclient", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.aarav.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        zoomKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.aarav.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, cat));

        ClientTickEvents.END_CLIENT_TICK.register(AaravClient::onTick);

        // Info HUD + targeted block
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("aarav7111sclient", "hud"),
                (ctx, tick) -> renderHud(ctx));

        // Custom crosshair replaces the vanilla one when enabled
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tick) -> {
            if (Modules.CROSSHAIR.enabled) renderCrosshair(ctx);
            else original.render(ctx, tick);
        });

        // Vanilla potion overlay is hidden when our Potion HUD is on
        HudElementRegistry.replaceElement(VanillaHudElements.STATUS_EFFECTS, original -> (ctx, tick) -> {
            if (!Modules.POTION_HUD.enabled) original.render(ctx, tick);
        });
    }

    private static void onTick(MinecraftClient mc) {
        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new ClientMenuScreen());
        }
        HudRenderer.tick(mc);
        if (mc.player == null) return;

        // Auto sprint: hold sprint whenever moving forward
        if (Modules.AUTO_SPRINT.enabled && mc.options.forwardKey.isPressed()
                && !mc.player.isSneaking() && !mc.player.isUsingItem()) {
            mc.options.sprintKey.setPressed(true);
        }

        // Fullbright via client-side night vision
        if (Modules.FULLBRIGHT.enabled) {
            mc.player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
    }

    private static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        var tr = mc.textRenderer;
        int x = 4, y = 4, white = 0xFFFFFFFF;

        if (Modules.HUD.enabled) {
            ctx.drawTextWithShadow(tr, NAME, x, y, 0xFF55FFFF);
            ctx.drawTextWithShadow(tr, "FPS: " + mc.getCurrentFps(), x, y += 11, white);
            ctx.drawTextWithShadow(tr, String.format("XYZ: %.1f / %.1f / %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()), x, y += 11, white);
            ctx.drawTextWithShadow(tr, "Facing: " + mc.player.getHorizontalFacing().asString(), x, y += 11, white);
            var net = mc.getNetworkHandler();
            var entry = net == null ? null : net.getPlayerListEntry(mc.player.getUuid());
            String ping = entry == null ? "-" : entry.getLatency() + "ms";
            String now = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
            ctx.drawTextWithShadow(tr, "Ping: " + ping + "  " + now, x, y += 11, white);
        }

        if (Modules.BLOCK_INFO.enabled && mc.world != null
                && mc.crosshairTarget instanceof BlockHitResult hit
                && hit.getType() == HitResult.Type.BLOCK) {
            var state = mc.world.getBlockState(hit.getBlockPos());
            String name = state.getBlock().getName().getString();
            var p = hit.getBlockPos();
            String text = "Looking at: " + name + " (" + p.getX() + ", " + p.getY() + ", " + p.getZ() + ")";
            int tx = (ctx.getScaledWindowWidth() - tr.getWidth(text)) / 2;
            ctx.drawTextWithShadow(tr, text, tx, 4, 0xFFFFFF55);
        }

        if (Modules.ARMOR_HUD.enabled) HudRenderer.renderArmor(ctx, mc, 6, 66);
        if (Modules.DURA_WARN.enabled) HudRenderer.renderWarning(ctx, mc);
        if (Modules.POTION_HUD.enabled) HudRenderer.renderPotions(ctx, mc);
        if (Modules.KEYSTROKES.enabled) HudRenderer.renderKeys(ctx, mc);
        else if (Modules.CPS.enabled) HudRenderer.renderCpsOnly(ctx, mc);
    }

    private static void renderCrosshair(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        int color = 0xFF00FFAA;
        int len = 5, gap = 2, t = 1;
        // four arms with a gap in the middle
        ctx.fill(cx - gap - len, cy - t / 2 - 0, cx - gap, cy + 1, color);
        ctx.fill(cx + gap + 1, cy - t / 2 - 0, cx + gap + 1 + len, cy + 1, color);
        ctx.fill(cx, cy - gap - len, cx + 1, cy - gap, color);
        ctx.fill(cx, cy + gap + 1, cx + 1, cy + gap + 1 + len, color);
    }

    private static void applyFpsBoost(GameOptions o, boolean on) {
        if (on) {
            o.getViewDistance().setValue(8);
            o.getSimulationDistance().setValue(6);
            o.getParticles().setValue(ParticlesMode.MINIMAL);
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            o.getEntityShadows().setValue(false);
            o.getGraphicsMode().setValue(GraphicsMode.FAST);
            o.getBiomeBlendRadius().setValue(0);
            o.getEntityDistanceScaling().setValue(0.5);
            o.getMaxFps().setValue(260);
            o.getEnableVsync().setValue(false);
        } else {
            o.getViewDistance().setValue(12);
            o.getSimulationDistance().setValue(10);
            o.getParticles().setValue(ParticlesMode.ALL);
            o.getCloudRenderMode().setValue(CloudRenderMode.FANCY);
            o.getEntityShadows().setValue(true);
            o.getGraphicsMode().setValue(GraphicsMode.FANCY);
            o.getBiomeBlendRadius().setValue(2);
            o.getEntityDistanceScaling().setValue(1.0);
        }
        o.write();
    }
}
