package com.aarav7111.client.mixin;

import com.aarav7111.client.AaravClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void aarav$zoom(Camera camera, float tickProgress, boolean changingFov,
                            CallbackInfoReturnable<Float> cir) {
        if (AaravClient.isZooming()) {
            cir.setReturnValue(cir.getReturnValue() / AaravClient.ZOOM_FACTOR);
        }
    }
}
