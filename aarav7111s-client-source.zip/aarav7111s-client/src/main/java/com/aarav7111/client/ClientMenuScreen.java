package com.aarav7111.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ClientMenuScreen extends Screen {
    public ClientMenuScreen() {
        super(Text.literal("Aarav7111s Client"));
    }

    private static Text label(Module m) {
        return Text.literal(m.name + ": " + (m.enabled ? "\u00a7aON" : "\u00a7cOFF"));
    }

    @Override
    protected void init() {
        int w = 150, h = 20, gap = 6;
        int startX = this.width / 2 - w - gap / 2;
        int startY = 50;
        int i = 0;
        for (Module m : Modules.ALL) {
            int col = i % 2, row = i / 2;
            int x = startX + col * (w + gap);
            int y = startY + row * (h + gap);
            addDrawableChild(ButtonWidget.builder(label(m), btn -> {
                m.enabled = !m.enabled;
                btn.setMessage(label(m));
                AaravClient.onModuleChanged(m);
                Modules.save();
            }).dimensions(x, y, w, h).build());
            i++;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(this.width / 2 - 50, this.height - 40, 100, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFF55FFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Click a module to enable/disable. Esc to close."),
                this.width / 2, 34, 0xFFAAAAAA);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
