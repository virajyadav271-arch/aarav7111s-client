# Aarav7111s Client (Fabric 1.21.11)

RIGHT SHIFT = module menu (click to enable/disable, saved automatically)
C (hold) = zoom

Modules: Info HUD (FPS/XYZ/facing/ping/time), Targeted Block, Custom Crosshair, Zoom,
Auto Sprint, Fullbright, FPS Boost, Armor HUD (durability), Low Durability Warning,
Potion HUD, Keystrokes, CPS Counter.

## Build the .jar
Local: JDK 21 + Gradle, run `gradle build` -> build/libs/aarav7111s-client-1.0.0.jar
Online: push to GitHub, Actions builds it (Actions tab -> Artifacts).
Put the jar in mods/ with Fabric Loader + Fabric API for 1.21.11.
